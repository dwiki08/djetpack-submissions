package com.dice.djetmovie.repository

object Constants {
    const val FILM_TYPE_MOVIE = "movie"
    const val FILM_TYPE_TV_SHOW = "tv_show"
}